package com.SpringJpaSP.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringJpaSP.model.CandidateDetail;
import com.SpringJpaSP.repository.MyRepository;

@Service
public class MyService 
{
  @Autowired
 private MyRepository MyRepo;
  

	public List<CandidateDetail> downloadCandidateDetailBasedOnMobNo(String mobNo)
	{    
		List<CandidateDetail> rs =this.MyRepo.downloadCandidateDetailBasedOnMobNo(mobNo);
		
		return rs;
	      	
	}
	
}
