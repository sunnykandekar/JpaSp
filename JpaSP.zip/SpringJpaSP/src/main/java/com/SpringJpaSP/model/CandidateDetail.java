package com.SpringJpaSP.model;

import javax.persistence.Entity;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;

@Entity
@NamedStoredProcedureQuery(name = "CandidateDetail.downloadCandidateDetailBasedOnMobNo",
procedureName = "sp_downloadCandidateDetailBasedOnMobNo",
parameters= {@StoredProcedureParameter(mode=ParameterMode.IN,name="i_userMobNo", type=String.class)}
           )
public class CandidateDetail {
	
	private String candidateName;
	private String nominationRegNo;
	private String candidateMobile;
	private int epId;

	private String electionProgramName;
	private int districtId;
	private String districtName;
	private int localBodyType;
	private String localBodyName;
	private int wardId;
	private int expCount;
	private String pollingDate;
	private String resultDate;	
	private int partyId;
	private String partyName;
	private String symbolName;
	private String isSymbolAllotted;
	private String withdrawalStatus;
	private int isInstalled;
	
	
	
	public int getEpId() {
		return epId;
	}
	public void setEpId(int epId) {
		this.epId = epId;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	
	
	public int getIsInstalled() {
		return isInstalled;
	}
	public void setIsInstalled(int isInstalled) {
		this.isInstalled = isInstalled;
	}
	
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	
	public int getPartyId() {
		return partyId;
	}
	public void setPartyId(int partyId) {
		this.partyId = partyId;
	}
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
	public String getSymbolName() {
		return symbolName;
	}
	public void setSymbolName(String symbolName) {
		this.symbolName = symbolName;
	}
	public String getIsSymbolAllotted() {
		return isSymbolAllotted;
	}
	public void setIsSymbolAllotted(String isSymbolAllotted) {
		this.isSymbolAllotted = isSymbolAllotted;
	}
	public String getWithdrawalStatus() {
		return withdrawalStatus;
	}
	public void setWithdrawalStatus(String withdrawalStatus) {
		this.withdrawalStatus = withdrawalStatus;
	}
	
	

	public String getPollingDate() {
		return pollingDate;
	}
	public void setPollingDate(String pollingDate) {
		this.pollingDate = pollingDate;
	}
	public String getResultDate() {
		return resultDate;
	}
	public void setResultDate(String resultDate) {
		this.resultDate = resultDate;
	}
	
	public String getNominationRegNo() {
		return nominationRegNo;
	}
	public void setNominationRegNo(String nominationRegNo) {
		this.nominationRegNo = nominationRegNo;
	}
	public String getCandidateMobile() {
		return candidateMobile;
	}
	public void setCandidateMobile(String candidateMobile) {
		this.candidateMobile = candidateMobile;
	}
	public String getElectionProgramName() {
		return electionProgramName;
	}
	public void setElectionProgramName(String electionProgramName) {
		this.electionProgramName = electionProgramName;
	}
	public int getDistrictId() {
		return districtId;
	}
	public void setDistrictId(int districtId) {
		this.districtId = districtId;
	}
	public int getLocalBodyType() {
		return localBodyType;
	}
	public void setLocalBodyType(int localBodyType) {
		this.localBodyType = localBodyType;
	}
	public String getLocalBodyName() {
		return localBodyName;
	}
	public void setLocalBodyName(String localBodyName) {
		this.localBodyName = localBodyName;
	}
	public int getWardId() {
		return wardId;
	}
	public void setWardId(int wardId) {
		this.wardId = wardId;
	}
	public int getExpCount() {
		return expCount;
	}
	public void setExpCount(int expCount) {
		this.expCount = expCount;
	}
	
	
	
	
}

