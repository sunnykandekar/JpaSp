package com.SpringJpaSP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaSpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaSpApplication.class, args);
	}

}
