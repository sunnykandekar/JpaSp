package com.SpringJpaSP.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;

import com.SpringJpaSP.model.CandidateDetail;

@Repository
public interface MyRepository  extends JpaRepository<CandidateDetail,Integer>
{

@Procedure(procedureName="sp_downloadCandidateDetailBasedOnMobNo")	
List<CandidateDetail> downloadCandidateDetailBasedOnMobNo(String mobNo);
	
}
