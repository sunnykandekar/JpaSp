package com.SpringJpaSP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaSpApplicationTests {

	@Test
	void contextLoads() {
	}

}
